def count_in_list(lst, elem):
    return lst.count(elem)


# def main():
#     print(count_in_list(["toto", "tata", "toto"], "tutu"))

# if __name__ == "__main__":
#     main()